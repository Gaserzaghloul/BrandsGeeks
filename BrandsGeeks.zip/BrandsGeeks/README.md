# BrandGeeks E-Commerce

A responsive full-stack e-commerce site with user authentication and shopping cart functionality.

**Tech:** HTML, CSS, JavaScript, Django  
**Features:**  
- Product browsing & order management  
- Responsive UI  
- Server-side data handling
